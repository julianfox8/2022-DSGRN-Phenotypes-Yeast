# Install and build
## Anaconda/Miniconda

To run any python scripts in this repo, you will need Python 3 with `pandas` and `numpy` dependencies.

A conda environment can be created by running the following:

```
$ conda env create -f gda_xscript.yml 
```

To run python scripts in this resulting conda environment, run the following before running any python scripts:

```
$ source activate gda_xscript
```
