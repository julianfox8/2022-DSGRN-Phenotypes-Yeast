# microarray_norm_rma

`normalize_microarray_rma.R` is the script that will be called to normalize RMA microarray data.

It has been written to be called from the command line according to the following instructions (these instuctions are also at the begininning of the R script):


A NOTE FOR HOW TO USE THIS CODE
the code should be called on the command line the following way
  from the root directory `<path/to>/gda_transcriptomics_process/`

```
Rscript ./microarray_norm_rma/normalize_microarray_rma.R <path_dirs_to_normalize> <output_directory> <subdirectory_to_normalize_1> <subdirectory_to_normalize_2> <etc>

```

\<path_dirs_to_normalize>\: is the file_path that leads to all subdirectories of files to normalize

\<output_directory\> : path where output will be saved (with a timestamp in the folder name)

each \<subdirectory_to_normalize\> is a directory name inside \<path_dirs_to_normalize\> that contains EXACTLY THE FOLLOWING:

 1) the necessary metadata file which has the name identical to the subdirectory plus '_metadata.tsv'
      e.g. the `bristow2014_GSE49650` folder contains the file `bristow2014_GSE49650_metadata.tsv`
      
 2) a CEL file subdirectory that ends in '_RAW' that contains (at least all of) the CEL files specified in the related metadata file

As for the other files in this directory:

`ExtractIDs.R` contains a function dependency for `normalize_microarray_rma.R`

`RemoveProbes.R` contains a function dependency for `normalize_microarray_rma.R`

`s_cerevisiae.msk` is a mask file used by `normalize_microarray_rma.R`

`yeast2annotation.csv` is a file dependency for `ExtractIDs.R`

## Outputs

The script `normalize_microarray_rma.R` outputs the following folder (in the directory specified for output when running the script)

+-- `<experiment_1_experiemnt_2...>_rma_<date>`: folder containing dchip normalized data with a set of included experiments

This folder will contain the following files:

|    +-- `<experiment_1_experiemnt_2...>_rma_<date>_all.tsv`: file containing all normalization results

|    +-- `<exp_name>_<cond>_<replicate_num>_rma_<date>_ts.tsv`: file containing time series (ts) <norm_method>
            normalization results for given experiment (exp_name),
            condition (cond), and replicate
             
|    +-- `<experiment_1_experiemnt_2...>_rma_<date>_readme.tsv`: read me file normalization procedure for files in folder

|    +-- `norm_gene_exp_dist.png`: violin plots of normalizations of the different types
