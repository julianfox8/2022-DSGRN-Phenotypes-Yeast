# Gary Koplik
# gary<dot>koplik<at>geomdata<dot>com
# August, 2018
# bristow2014.ipynb

import pandas as pd
import os
import sys, argparse
import shared._data_tracking as dattrk


def simmons_kovacs_2012_all_metadata(raw_dat):
    """
    convert raw data into desired metadata only
    :param raw_dat (pd df): raw data from Simmons Kovacs 2012
    """
    to_keep = ['!Sample_title', '!Sample_geo_accession', '!Sample_supplementary_file',
               '!Sample_type', '!Sample_organism_ch1', '!Sample_characteristics_ch1',
               '!Sample_growth_protocol_ch1']

    transposed_subset = raw_dat.loc[to_keep].T

    # file name column
    transposed_subset['file'] = transposed_subset['!Sample_supplementary_file'].apply(os.path.basename)

    # experiment column
    transposed_subset['experiment'] = 'simmonskovacs2012'

    # break title into its pieces
    transposed_subset['title'] = transposed_subset['!Sample_title']

    # break title into condition, time, and replicate
    temp_sample_title_split = pd.DataFrame(transposed_subset['!Sample_title'].str.split(", ", expand=True))
    transposed_subset['condition'] = temp_sample_title_split.iloc[:, 0] + '_' + temp_sample_title_split.iloc[:, 1].str.replace(" degrees", "C")
    transposed_subset['time'], transposed_subset['replicate'] = \
        temp_sample_title_split.iloc[:, 2].str.strip("t="), \
        temp_sample_title_split.iloc[:, 3].str.strip("replicate ")

    transposed_subset['replicate'].fillna(value=1, inplace=True)

    # break Sample_growth_protocol_ch1 into growth and treatment
    temp_sample_growth_split = pd.DataFrame(
        transposed_subset['!Sample_growth_protocol_ch1'].str.split(".  ", expand=True))
    transposed_subset['treatment'] = temp_sample_growth_split.iloc[:, 1]
    transposed_subset['growth'] = temp_sample_growth_split.iloc[:, 0] + ".  " + \
                                  temp_sample_growth_split.iloc[:,2] + ".  " + temp_sample_growth_split.iloc[:, 3]

    # rename several columns to be more understandable
    transposed_subset = transposed_subset. \
        rename(index=str, columns={'!Sample_geo_accession': "geo_accession",
                                   '!Sample_type': 'sample_type',
                                   '!Sample_organism_ch1': 'organism',
                                   '!Sample_characteristics_ch1': 'characteristics'})

    # keep variables we want
    final_vars = ['title', 'geo_accession', 'file', 'experiment', 'condition', 'replicate', 'time',
                  'organism', 'characteristics', 'treatment', 'growth', 'sample_type']
    return transposed_subset.loc[:, final_vars]


def cho2019_all_metadata(raw_dat):
    """
    convert raw data into desired metadata only
    :param raw_dat (pd df): raw data from Cho 2019
    """
    to_keep = ['!Sample_title', '!Sample_geo_accession', '!Sample_supplementary_file',
               '!Sample_type', '!Sample_organism_ch1', '!Sample_characteristics_ch1',
               '!Sample_treatment_protocol_ch1', '!Sample_growth_protocol_ch1']

    transposed_subset = raw_dat.loc[to_keep].T

    # file name column
    transposed_subset['file'] = transposed_subset['!Sample_supplementary_file'].apply(os.path.basename)

    # experiment column
    transposed_subset['experiment'] = 'cho2019'

    # break title into its pieces
    transposed_subset['title'] = transposed_subset['!Sample_title']

    # break title into condition, time, and replicate
    temp_sample_title_split = pd.DataFrame(transposed_subset['!Sample_title'].str.split("_", expand=True))

    scere_df = temp_sample_title_split[temp_sample_title_split[0] == 'Cerevisiae']
    cdc28whi5stb1 = scere_df[scere_df[1] == 'cdc28whi5stb1']
    # first set of samples
    cdc28whi5stb1_elutr = cdc28whi5stb1[cdc28whi5stb1[2] == 'elutr']
    cdc28whi5stb1_elutr = cdc28whi5stb1_elutr[[1, 3, 4]]
    cdc28whi5stb1_elutr[1] = cdc28whi5stb1_elutr[1] + '_elutr'
    # second set of samples
    cdc28whi5stb1 = cdc28whi5stb1[cdc28whi5stb1[2] != 'elutr']
    cdc28whi5stb1 = cdc28whi5stb1[[1, 2, 3]]
    cdc28whi5stb1 = cdc28whi5stb1.rename(columns={2: 3, 3: 4})
    # third set of samples
    cdc16cdc28whi5stb1 = scere_df[scere_df[1] == 'cdc16cdc28whi5stb1']
    cdc16cdc28whi5stb1 = cdc16cdc28whi5stb1[[1, 2, 3]]
    cdc16cdc28whi5stb1 = cdc16cdc28whi5stb1.rename(columns={2: 3, 3: 4})

    GAL12 = temp_sample_title_split[temp_sample_title_split[0] != 'Cerevisiae']
    # fourth set of samples
    GAL1 = GAL12[GAL12[1] != 'biological']
    GAL1[0] = GAL1[0] + '_' + GAL1[1]
    GAL1 = GAL1[[0, 4, 3]]
    GAL1 = GAL1.rename(columns={0: 1, 4: 3, 3: 4})
    # fifth set of samples
    GAL2 = GAL12[GAL12[1] == 'biological']
    GAL2 = GAL2[[0, 3, 2]]
    GAL2 = GAL2.rename(columns={0: 1, 3: 3, 2: 4})

    info_df_split = cdc28whi5stb1_elutr.append([cdc28whi5stb1, cdc16cdc28whi5stb1, GAL1, GAL2])

    transposed_subset['condition'], transposed_subset['time'], transposed_subset['replicate'] = \
        info_df_split.iloc[:, 0], \
        info_df_split.iloc[:, 1].str.strip("min"), \
        info_df_split.iloc[:, 2].str.strip("rep")

    #   rename several columns to be more understandable
    transposed_subset = transposed_subset. \
        rename(index=str, columns={'!Sample_geo_accession': "geo_accession",
                                   '!Sample_type': 'sample_type',
                                   '!Sample_organism_ch1': 'organism',
                                   '!Sample_characteristics_ch1': 'characteristics',
                                   '!Sample_treatment_protocol_ch1': 'treatment',
                                   '!Sample_growth_protocol_ch1': 'growth'})

    # keep variables we want
    final_vars = ['title', 'geo_accession', 'file', 'experiment', 'condition', 'replicate', 'time',
                  'organism', 'characteristics', 'treatment', 'growth', 'sample_type']
    return transposed_subset.loc[:, final_vars]


def cho2017_all_metadata(raw_dat):
    """
    convert raw data into desired metadata only
    :param raw_dat (pd df): raw data from Cho 2017
    """
    to_keep = ['!Sample_title', '!Sample_geo_accession', '!Sample_supplementary_file',
               '!Sample_type', '!Sample_organism_ch1', '!Sample_characteristics_ch1',
               '!Sample_treatment_protocol_ch1', '!Sample_growth_protocol_ch1']

    transposed_subset = raw_dat.loc[to_keep].T

    # file name column
    transposed_subset['file'] = transposed_subset['!Sample_supplementary_file'].apply(os.path.basename)

    # experiment column
    transposed_subset['experiment'] = 'cho2017'

    # break title into its pieces
    transposed_subset['title'] = transposed_subset['!Sample_title']

    # break title into its pieces
    transposed_subset['title'] = transposed_subset['!Sample_title']

    # break title into condition, time, and replicate
    temp_sample_title_split = pd.DataFrame(transposed_subset['!Sample_title'].str.split("_", expand=True))
    transposed_subset['condition'], transposed_subset['time'] = temp_sample_title_split.iloc[:,
                                                                0], temp_sample_title_split.iloc[:, 1].str.strip("min")

    transposed_subset['replicate'] = 1

    #   rename several columns to be more understandable
    transposed_subset = transposed_subset. \
        rename(index=str, columns={'!Sample_geo_accession': "geo_accession",
                                   '!Sample_type': 'sample_type',
                                   '!Sample_organism_ch1': 'organism',
                                   '!Sample_characteristics_ch1': 'characteristics',
                                   '!Sample_treatment_protocol_ch1': 'treatment',
                                   '!Sample_growth_protocol_ch1': 'growth'})

    # keep variables we want
    final_vars = ['title', 'geo_accession', 'file', 'experiment', 'condition', 'replicate', 'time',
                  'organism', 'characteristics', 'treatment', 'growth', 'sample_type']
    return transposed_subset.loc[:, final_vars]


def bristow2014_all_metadata(raw_dat):
    """
    convert raw data into desired metadata only
    :param raw_dat (pd df): raw data from Bristow 2014
    """
    # rows of raw_dat to keep
    to_keep = ['!Sample_title', '!Sample_geo_accession', '!Sample_supplementary_file',
               '!Sample_type', '!Sample_organism_ch1', '!Sample_characteristics_ch1',
               '!Sample_treatment_protocol_ch1', '!Sample_growth_protocol_ch1']
    transposed_subset = raw_dat.loc[to_keep].T

    # file name column
    transposed_subset['file'] = transposed_subset['!Sample_supplementary_file'].apply(os.path.basename)

    # experiment column
    transposed_subset['experiment'] = 'bristow2014'

    # break title into its pieces
    transposed_subset['title'] = transposed_subset['!Sample_title']

    # break title into condition, time, and replicate
    temp_sample_title_split = pd.DataFrame(transposed_subset['!Sample_title'].str.split("_", expand=True))
    transposed_subset['condition'], transposed_subset['time'], transposed_subset['replicate'] = \
        temp_sample_title_split.iloc[:, 1], \
        temp_sample_title_split.iloc[:, 2].str.strip("min"), \
        temp_sample_title_split.iloc[:, 3].str.strip("rep")

    # rename several columns to be more understandable
    transposed_subset = transposed_subset. \
        rename(index=str, columns={'!Sample_geo_accession': "geo_accession",
                                   '!Sample_type': 'sample_type',
                                   '!Sample_organism_ch1': 'organism',
                                   '!Sample_characteristics_ch1': 'characteristics',
                                   '!Sample_treatment_protocol_ch1': 'treatment',
                                   '!Sample_growth_protocol_ch1': 'growth'})

    # keep variables we want
    final_vars = ['title', 'geo_accession', 'file', 'experiment', 'condition', 'replicate', 'time',
                  'organism', 'characteristics', 'treatment', 'growth', 'sample_type']
    return transposed_subset.loc[:, final_vars]


# def bristow2014_all_subfiles(completed_metadata):
#     """
#     take completed metadata file and save all subfiles (splitting on condition and replicate)
#     :param completed_metadata (pd df): converted raw data
#     """
#     print("Making the Following subgroup files:")
#     for name, group in completed_metadata.groupby(by=['condition', 'replicate']):
#         print(f'\t condition {name[0]} rep {name[1]}')
#         group.to_csv(f'../data/bristow2014_GSE49650__{name[0]}_r{name[1]}_metadata.tsv',
#                      index=False, sep='\t')


def orlando_all_metadata(raw_dat):
    """
    convert raw data into desired metadata only
    :param raw_dat (pd df): raw data from Orlando
    """
    # rows of raw_dat to keep
    to_keep = ['!Sample_title', '!Sample_geo_accession', '!Sample_supplementary_file',
               '!Sample_type', '!Sample_organism_ch1', '!Sample_characteristics_ch1',
               '!Sample_treatment_protocol_ch1', '!Sample_growth_protocol_ch1']
    transposed_subset = raw_dat.loc[to_keep].T

    # file name column (you end up with two identical file names, index 0 is cel files e.g. what we want)
    transposed_subset['file'] = transposed_subset['!Sample_supplementary_file'].apply(os.path.basename)
    transposed_subset['file'] = transposed_subset['file'].str.replace('CHP.gz', 'CEL')
    # experiment column
    transposed_subset['experiment'] = 'orlando2008'

    # break title into its pieces
    transposed_subset['title'] = transposed_subset['!Sample_title']

    # break title into condition, time, and replicate
    temp_sample_title_split = pd.DataFrame(transposed_subset['!Sample_title'].str.split("_", expand=True))
    transposed_subset['condition'], transposed_subset['time'], transposed_subset['replicate'] = \
        temp_sample_title_split.iloc[:, 1], \
        temp_sample_title_split.iloc[:, 2].str.strip("min"), \
        temp_sample_title_split.iloc[:, 3].str.strip("rep")

    # rename several columns to be more understandable
    transposed_subset = transposed_subset. \
        rename(index=str, columns={'!Sample_geo_accession': "geo_accession",
                                   '!Sample_type': 'sample_type',
                                   '!Sample_organism_ch1': 'organism',
                                   '!Sample_characteristics_ch1': 'characteristics',
                                   '!Sample_treatment_protocol_ch1': 'treatment',
                                   '!Sample_growth_protocol_ch1': 'growth'})

    # keep variables we want
    final_vars = ['title', 'geo_accession', 'file', 'experiment', 'condition', 'replicate', 'time',
                  'organism', 'characteristics', 'treatment', 'growth', 'sample_type']
    return transposed_subset.loc[:, final_vars]


def kelliher2016_all_metadata(raw_dat, ncbi_dat):
    """
    convert raw data into desired metadata only
    :param raw_dat (pd df): raw data from kelliher2016
    :param ncbi_dat (pd df): ncbi dat about related fastq files
    """
    # rows of raw_dat to keep
    to_keep = ['!Sample_title', '!Sample_geo_accession',
               '!Sample_type', '!Sample_organism_ch1', '!Sample_characteristics_ch1',
               '!Sample_treatment_protocol_ch1', '!Sample_growth_protocol_ch1']
    transposed_subset = raw_dat.loc[to_keep].T

    # experiment column
    transposed_subset['experiment'] = 'kelliher2016'

    # break title into its pieces
    transposed_subset['title'] = transposed_subset['!Sample_title']

    # characteristics var we want is first of 3 identical names...
    transposed_subset['characteristics'] = transposed_subset['!Sample_characteristics_ch1'].iloc[:, 0]

    # treatment var we want is first of 2 identical names...
    transposed_subset['treatment'] = transposed_subset['!Sample_treatment_protocol_ch1'].iloc[:, 0]

    # break title into condition, time, and replicate
    temp_sample_title_split = pd.DataFrame(transposed_subset['!Sample_title'].str.split("_", expand=True))
    transposed_subset['condition'], transposed_subset['time'] =\
        temp_sample_title_split.iloc[:, 1], temp_sample_title_split.iloc[:, 3].str.strip("min")

    # rename several columns to be more understandable
    transposed_subset = transposed_subset. \
        rename(index=str, columns={'!Sample_geo_accession': "geo_accession",
                                   '!Sample_type': 'sample_type',
                                   '!Sample_organism_ch1': 'organism',
                                   '!Sample_growth_protocol_ch1': 'growth'})

    # include fastq filenames
    temp = ncbi_dat.loc[:, ['Run', 'Sample_Name']]
    temp['Run'] = temp['Run'] + '_1.fastq'
    temp = temp.rename(index = str, columns = {'Run': 'file'})
    transposed_subset = pd.merge(transposed_subset, temp,
                                 left_on = 'geo_accession', right_on = 'Sample_Name',
                                 how = 'left')

    # no replicates here so default all to 1
    transposed_subset['replicate'] = 1

    # keep variables we want
    final_vars = ['title', 'geo_accession', 'file', 'experiment', 'condition', 'replicate',
                  'time', 'organism', 'characteristics', 'treatment', 'growth', 'sample_type']
    df = transposed_subset.loc[:, final_vars]
    
    return df


experiments_list = ['simmonskovacs2012', 'cho2019', 'cho2017', 'bristow2014', 'orlando2008', 'kelliher2016']

if __name__ == '__main__':

    ### code for making bristow metadata files ###

    """
    Note this script is anticipated currently to be run as:
    ```
    python extract_geo_metadata.py <path_to_series_matrix.txt> <name_of_dataset> <#_of_rows_to_skip>
    ```
    from the ~/get_metadata_from_geo/scripts/ directory
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("-data_path", help="path to the data file to add info to")
    parser.add_argument("-dataset_name", help="the name of the dataset to make the metadata file for.")
    parser.add_argument("-skiprows", help="the number of rows to skip in the *_series_matrix.txt files. These rows are typically '!Series_*' titled rows and the blank row before the '!Sample_*' rows.")
    args = parser.parse_args()
    data_path = args.data_path
    dataset_name = args.dataset_name
    skiprows = int(args.skiprows)

    dataset_name = dataset_name.lower()

    if dataset_name not in experiments_list:
        print('Please make sure that the datasets is either in the experiments list or spelled correct')
        for exp in experiments_list:
            print(exp)
    else:
        # get data processing documentation
        doc_info = dattrk.get_doc_info_string(__file__, sys.argv, vars(parser.parse_args()))
        # if there are comments from the input file you want to copy into the new file
        comments = dattrk.get_data_file_comments(data_path, input_comment = '!', output_comment = "#", num_lines = 5)
        out_path_no_metadata = data_path.replace("_series_matrix", "")
        out_path = dattrk.add_suffix_to_file_path(out_path_no_metadata, '_metadata.tsv')
        print("saving to: " + out_path)

        # read original metadata file (specified in args) # Note very specific to bristow2014_GSE49650_series_matrix.txt
        raw_metadat = pd.read_csv(data_path, sep="\t",
                                  error_bad_lines=False, skiprows=skiprows,
                                  header=None, low_memory=False, index_col=0)

        # put into collective form we want
        if dataset_name == 'simmonskovacs2012':
            transposed_subset = simmons_kovacs_2012_all_metadata(raw_metadat)
        elif dataset_name == 'cho2019':
            transposed_subset = cho2019_all_metadata(raw_metadat)
        elif dataset_name == 'cho2017':
            transposed_subset = cho2017_all_metadata(raw_metadat)
        elif dataset_name == 'bristow2014':
            transposed_subset = bristow2014_all_metadata(raw_metadat)
        elif dataset_name == 'orlando2008':
            transposed_subset = orlando_all_metadata(raw_metadat)

        # kelliher2016 needs an NCBI file. See commented code below.
        # if dataset_name == 'kelliher2016':
        #     transposed_subset = kelliher2016_all_metadata(raw_metadat)

        with open(out_path, 'w') as out_file:
            out_file.write(doc_info)
            out_file.write("# \n")
            out_file.write(comments)
            out_file.write("# \n")
            transposed_subset.to_csv(out_file, index=False, sep='\t')

        # on behalf of the biologists make the metadata files broken up by condition and replicate
        for name, group in transposed_subset.groupby(by=['condition', 'replicate']):
            print(f'\t condition {name[0]} rep {name[1]}')
            out_path_subfile = dattrk.add_suffix_to_file_path(out_path_no_metadata, f"__{name[0]}_r{name[1]}_metadata.tsv")
            with open(out_path_subfile, 'w') as out_file:
                out_file.write(doc_info) # same doc_info as before
                out_file.write(f"# subset of: {os.path.basename(out_path)}")
                out_file.write("\n")
                out_file.write(f"#   using condition {name[0]} and replicate {name[1]}")
                out_file.write("\n")
                out_file.write(comments)
                out_file.write("# \n")
                group.to_csv(out_file, index=False, sep='\t')

    
    ### code for making orlando2008 metadata files ###
    # (basically, the same, but separated to decrease chance of calling wrong function)

    """
    Note this script is anticipated currently to be run as:
    ```
    python extract_geo_metadata.py ../data/orlando2008_GSE8799_series_matrix.txt
    ```
    from the ~/get_metadata_from_geo/scripts/ directory
    """
#     parser = argparse.ArgumentParser()
#     parser.add_argument("data_path", help="path to the data file to add info to")
#     args = parser.parse_args()
#     data_path = args.data_path

#     # get data processing documentation
#     doc_info = dattrk.get_doc_info_string(__file__, sys.argv, vars(parser.parse_args()))
#     # if there are comments from the input file you want to copy into the new file
#     comments = dattrk.get_data_file_comments(data_path, input_comment = '!', output_comment = "#", num_lines = 5)
#     out_path_no_metadata = data_path.replace("_series_matrix", "")
#     out_path = dattrk.add_suffix_to_file_path(out_path_no_metadata, '_metadata.tsv')
#     print("saving to: " + out_path)

#     # read original metadata file (specified in args) # Note very specific to bristow2014_GSE49650_series_matrix.txt
#     raw_metadat = pd.read_csv(data_path, sep="\t",
#                               error_bad_lines=False, skiprows=32,
#                               header=None, low_memory=False, index_col=0)

#     # put into collective form we want
#     transposed_subset = orlando_all_metadata(raw_metadat)

#     with open(out_path, 'w') as out_file:
#         out_file.write(doc_info)
#         out_file.write("# \n")
#         out_file.write(comments)
#         out_file.write("# \n")
#         transposed_subset.to_csv(out_file, index=False, sep='\t')

#     # on behalf of the biologists make the metadata files broken up by condition and replicate
#     for name, group in transposed_subset.groupby(by=['condition', 'replicate']):
#         print(f'\t condition {name[0]} rep {name[1]}')
#         out_path_subfile = dattrk.add_suffix_to_file_path(out_path_no_metadata, f"__{name[0]}_r{name[1]}_metadata.tsv")
#         with open(out_path_subfile, 'w') as out_file:
#             out_file.write(doc_info) # same doc_info as before
#             out_file.write(f"# subset of: {os.path.basename(out_path)}")
#             out_file.write("\n")
#             out_file.write(f"#   using condition {name[0]} and replicate {name[1]}")
#             out_file.write("\n")
#             out_file.write(comments)
#             out_file.write("# \n")
#             group.to_csv(out_file, index=False, sep='\t')
            
    ### code for making kelliher2016 metadata files ###
    # (similar, but requires an additional ncbi file)

    """
    Note this script is anticipated currently to be run as:
    
    ```
    python extract_geo_metadata.py --data_path ../data/GSE80474-GPL17342_series_matrix.txt --ncbi_path ../data/SraRunTable_SRP073615.txt
    
    ```
    
    from the ~/get_metadata_from_geo/scripts/ directory
    """
#     parser = argparse.ArgumentParser()
    
#     parser.add_argument("--data_path", help="path to the data file to add info to")
#     parser.add_argument("--ncbi_path", help="path to ncbi data file")
    
#     args = parser.parse_args()
#     data_path = args.data_path
#     ncbi_path = args.ncbi_path

#     # get data processing documentation
#     doc_info = dattrk.get_doc_info_string(__file__, sys.argv, vars(parser.parse_args()))
#     # if there are comments from the input file you want to copy into the new file
#     comments = dattrk.get_data_file_comments(data_path, input_comment = '!', output_comment = "#", num_lines = 5)
#     out_path = data_path.replace("_series_matrix", "")
#     out_path = dattrk.add_suffix_to_file_path(out_path, '_metadata.tsv')
#     print("saving to: " + out_path)

#     # read original metadata file (specified in args) # Note very specific to bristow2014_GSE49650_series_matrix.txt
#     raw_metadat = pd.read_csv(data_path, sep="\t",
#                               error_bad_lines=False, skiprows=34,
#                               header=None, low_memory=False, index_col=0)
    
#     ncbi_dat = pd.read_csv(ncbi_path, sep = '\t')

#     # put into collective form we want
#     transposed_subset = kelliher2016_all_metadata(raw_metadat, ncbi_dat)

#     with open(out_path, 'w') as out_file:
#         out_file.write(doc_info)
#         out_file.write("# \n")
#         out_file.write(comments)
#         out_file.write("# \n")
#         transposed_subset.to_csv(out_file, index=False, sep='\t')
