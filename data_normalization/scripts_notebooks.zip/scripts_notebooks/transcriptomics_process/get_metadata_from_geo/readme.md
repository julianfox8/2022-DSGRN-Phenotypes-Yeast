# get_metadata_from_geo

get metadata from GEO data into a usable format

`extract_geo_metadata.py` has custom functions for converting the GEO metadata into a usable format for the `normalize_microarray_<dchip or rma>` files.

NOTE: you will almost certainly need your own custom function for a different data set due to idiosyncracies between metadata files.

At the time of writing this documentation, there are functions written to change the metadata for `Bristow2014`, `Orlando2008`, and `Kelliher2016`, 
    all of which have slight differences (which thus all have slightly different functions).

One of the most common issues worth mentioning here was repeated row names for rows of interest. Resolving these required hand-checking which row was needed 
    and then hard-coding the selection of the correct row.
    
As for most relevant notes of what pieces of information you will need to not break later scripts that use this metadata, in particular, 
    note the following from the functions already written:
    
- the chosen row names specified under the line comment `# rows of raw_dat to keep`

- the renaming of kept variables specified under the line comment `# rename several columns to be more understandable`

- the final selection / ordering specified under the line comment `# keep variables we want`


