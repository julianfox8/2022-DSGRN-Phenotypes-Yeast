# microarray_clean

Using an annotated tsv file, we clean out probes for affymetrix yeast s98 or 2.0 microarrays. Probes are removed if:
* they do not map to an SGD ID
* they do not map to a systematic name (e.g. YKR009C)
* the probe maps to multiple genes
* there are "questionable probes" (e.g. probes with `_<X>_at` suffix, where X = s,f,g,x,i,r)

Note that we do not check or get rid of gene ids that are duplicated; we leave that to the user to decide how to deal with them. But most methods cannot handle them, so they should be removed by dropping all of them or using some selection criteria (e.g. min expression, max expression, etc)

## Running
requires microarray data be run through the annotate script first, so you have a <mydataset>_annot.tsv file.

for affymetrix yeast 2.0 microarray data:  
`python clean_affy_yeast2.py /path/to/<data set>_annot.tsv`

for affymetrix yeast s98 microarray data:  
`python clean_affy_yeasts98.py /path/to/<data set>_annot.tsv`

## Input
`<data_annot>.tsv`
requires microarray data be run through the annotate script first.

* a tab delimited file
* comments rows start with a "#"
* a header row with column names
* requires columns from the annotate script output: sgd_id, probe, sys_name

## Output
`<data_annot>_clean.tsv`
* original tsv data with rows removed, and info about what was removed in the header.