'''
clean out affy yeast 2 data to remove probes with missing gene info and questionable probes.

:author: anastasia deckard
:email: anastasia.deckard@geomdata.com
:copyright: (c) 2018, GDA
:license: , see LICENSE for more details
'''

import os, argparse, sys
import pandas as pd
import shared._data_tracking as dattrk

parser = argparse.ArgumentParser()
parser.add_argument("-input_path", help="path to the data file to add info to")
args = parser.parse_args()

input_path = args.input_path

# get data processing documentation
doc_info = dattrk.get_doc_info_string(__file__, sys.argv, vars(parser.parse_args()))
data_comments = dattrk.get_data_file_comments(input_path)

# read rnaseq data
data_df = pd.read_csv(input_path, sep='\t', header=0, comment='#', dtype=str)

clean_data_df = data_df
print("# probes: ", len(clean_data_df))

# get rid of missing sgd_id
clean_data_df.dropna(subset=['sgd_id'], inplace=True)
print("- miss sgd_id: ", len(clean_data_df))

# get rid of missing sys_name
clean_data_df.dropna(subset=['sys_name'], inplace=True)
print("- miss sys_name: ", len(clean_data_df))

# get rid of probe -> multi genes
clean_data_df = clean_data_df[clean_data_df['sgd_id'].str.contains("///") == False]
print("- multi genes: ", len(clean_data_df))

# get rid of duplicated _x_ and _s_ probe ids
clean_data_df = clean_data_df[clean_data_df['probe'].str.contains("_x_") == False]
clean_data_df = clean_data_df[clean_data_df['probe'].str.contains("_s_") == False]
print("- x, s probes: ", len(clean_data_df))

output_path = (input_path + "_clean.txt").replace(".txt_", "_").replace(".tsv_", "_")
with open(output_path, 'w') as out_file:
    out_file.write(data_comments)
    out_file.write(doc_info)
    out_file.write("# records: {:d}\n".format(len(clean_data_df)))
    out_file.write("# uniq sgd_id: {:d}\n".format(len(clean_data_df['sgd_id'].unique())))
    out_file.write("#\n")
    clean_data_df.to_csv(out_file, sep='\t', index=False, header=True)
