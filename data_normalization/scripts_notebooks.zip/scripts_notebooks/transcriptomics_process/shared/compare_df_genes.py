# Gary Koplik
# gary<dot>koplik<at>geomdata<dot>com
# compare_df_genes.py

"""
Read in two tsv files (df1 and df2) and the column names to compare (col1 and col2)
prints out comparisons of two columns (intersection and difference) in the terminal

Run something like:

```
python compare_df_genes.py --df1 ~/sd2e-community/shared-q1-workshop/adeckard/cp-yeaststates/diff_exp_subsets_201806/de_dchip_20180626_annot_pv1e-40_fc4.0_mda2000/de_dchip_20180626_annot_pv1e-40_fc4.0_mda2000.txt --df2 ~/tacc-work/gda_ext_data_process/cp-yeaststates/maxsep_rho0_wt_wt37d_20181012192451/maxsep_rho0_wt_wt37d_top10/rho0_wt_wt37d_maxsep_annot_clean_top10.tsv --col1 symbol --col2 symbol --output_path ./
```
"""

import sys, argparse
import pandas as pd
import os

parser = argparse.ArgumentParser()
parser.add_argument("--df1", help = "path to first tsv file to compare")
parser.add_argument("--df2", help = "path to second tsv file to compare")
parser.add_argument("--col1", help = "name of column in first tsv file to compare")
parser.add_argument("--col2", help = "name of column in second tsv file to compare")
parser.add_argument("--output_path", help = "where to write results")

args = parser.parse_args()

output_path = args.output_path

# read in dfs

df1 = pd.read_csv(args.df1, comment = '#', sep = '\t')
df2 = pd.read_csv(args.df2, comment = '#', sep = '\t')

# get the relevant columns to compare

col1 = df1.loc[:, args.col1].values
col2 = df2.loc[:, args.col2].values

# find overlap and differences between two cols
overlap = set(col1).intersection(col2)
df1_unique_vals = set(col1) - overlap
df2_unique_vals = set(col2) - overlap


with open(os.path.join(output_path, 'overlap__{}__{}.txt'.format(os.path.basename(args.df1),
                                                                 os.path.basename(args.df2))), 'w') as out_file:
    out_file.write("Overlap of the two lists:")
    out_file.write(str(overlap))
    out_file.write('\n\n\n')

    out_file.write("Values only in {} from {}:\n".format(args.col1, os.path.basename(args.df1)))
    out_file.write(str(df1_unique_vals))
    out_file.write('\n\n\n')

    out_file.write("Values only in {} from {}:\n".format(args.col2, os.path.basename(args.df2)))
    out_file.write(str(df2_unique_vals))

      
