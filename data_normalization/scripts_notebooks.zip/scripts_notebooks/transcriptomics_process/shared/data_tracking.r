

# this has to be pasted into the r code; i don't think it works from this file
def get_doc_info_string(file, cmd, args){
file_name = parent.frame(2)$ofile
file_dir = dirname(this.file)
datetime_stamp = format(sys.time, '%Y%m%d %h%m%s')
login_name = Sys.info()[["user"]]
}