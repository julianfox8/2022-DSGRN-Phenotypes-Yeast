"""
storing information about data processing in the data files

tested for: py 3.5

:author: Anastasia Deckard
:email: anastasia<dot>deckard<at>duke<dot>edu
:created: 2014 07 28
:copyright: (c) 2015, Anastasia Deckard
:license: New BSD License, see LICENSE for more details
"""

import os, sys, re
from datetime import datetime
import tarfile, zipfile
import pandas


def get_doc_info_string(file, cmd, args):
	"""

	doc_for_file = data_tracking.get_doc_info_string(__file__, sys.argv, vars(parser.parse_args()))

	:param file:
	:param doc:
	:param cmd:
	:param args:
	:return:
	"""

	script_version = datetime.fromtimestamp(os.path.getmtime(file)).strftime("%Y %m %d %H:%M:%S")
	script_executed = datetime.today().strftime("%Y %m %d %H:%M:%S")

	doc_for_file = [
		"### script: " + os.path.basename(file) + " version: " + script_version,
		"# run by:   " + os.getlogin(),
		"# run on:   " + script_executed,
		"# cmd:      " + ' '.join(cmd),
		"# params:   " + '\n#           '.join([str(x) + ": " + str(y) for x, y in args.items()]),
		"#\n"]

	return '\n'.join(doc_for_file)


def get_data_file_comments(filename, comment='#', sep='\t'):
	"""
	get comment lines from a data file

	:param filename: path to file
	:param comment: default is "#", symbol for comments
	:param sep: default is "\t", symbol for delimiter
	:returns: list of lines with comments
	"""
	with open(filename, 'r') as file_handle:
		file_tmp = file_handle.read()
		file_tmp = file_tmp.splitlines()
		file_comments = [line for line in file_tmp if line.startswith(comment)]
		file_comments = file_comments + ["#\n"]

	return '\n'.join(file_comments)


def add_suffix_to_file_path(input_file_path, suffix_ext):
	"""
	adds new suffix and extension to a file path

	:param filename: [description]
	:param suffix_ext: new suffix and extension, e.g. _annot.txt
	:return: [description]
	"""

	input_file_name, input_file_ext = os.path.splitext(os.path.basename(input_file_path))
	output_file_path = input_file_path.replace(input_file_ext, suffix_ext)

	return output_file_path