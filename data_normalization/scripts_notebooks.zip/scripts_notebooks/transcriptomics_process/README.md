# Processing Transcriptomics Data

packages from processing transcriptomics data, especially microarray data.
These can be used together as a pipeline, or individually for data that has already been processed to a given stage.

See the readme.md file in each folder for more details on how to run, input, and output.

## get_meta_data_from_GEO
functions for converting GEO metadata, for both RNA-seq and microarray, to our metadata format. these need to be customized for each GEO data set because the values in GEO fields are not necessarily consistent.


## microarray_norm_dchip, microarray_norm_rma
processes raw CEL files and metadata files. normalizes all CEL files together.

Output: 
* a tsv file with genes by all samples
* a tsv file of time series for each experiment with genes by time.  
* plot of distributions of gene expressions per experiment.

## annotate
attach gene names, symbols, species database (SGD, MGI, etc) ids. Currently included are affymetrix yeast s98 and 2.0 probe sets. Also included is the SGD data for use to convert between systematic name, common name, and SGD ID, which can be used on RNA-seq data sets.

Output:
`<dataset>_annot.tsv`
* original tsv data with columns added for gene names, symbols, ids.


## microarray_clean
Using an annotated tsv file, we clean out probes for affymetrix yeast s98 or 2.0 microarrays. Probes are removed if:
* they do not map to an SGD ID
* they do not map to a systematic name (e.g. YKR009C)
* the probe maps to multiple genes
* there are "questionable probes" (e.g. probes with \_\<X>_at suffix, where X = s,f,g,x,i,r)
Note that we do not check or get rid of gene ids that are duplicated; we leave that to the user to decide how to deal with them. But most methods cannot handle them, so they should be removed by dropping all of them or using some selection criteria (e.g. min expression, max expression, etc)

Output:
`<dataset_annot>_clean.tsv`
* original tsv data with rows removed, and info about what was removed in the header.