"""
attach gene information to files.

uses map_info py and json to make consistent formats.
uses map files from platform (affy), species naming orgs (sgd, mgi, tair, etc.),
or from group for custom or older arrays (whitfield, spellman).
Our preference is to use probe <-> id maps from species naming orgs
when available.
Also handles replacing all the different types of blanks and nulls with np.nan
The new file will be written back into the data file directory,
with the suffix "annot" on the file name.

tested for: py 3.5

:author: Anastasia Deckard
:email: anastasia<dot>deckard<at>duke<dot>edu
:created: 2015 10 12
:copyright: (c) 2015, Anastasia Deckard
:license: New BSD License, see LICENSE for more details
"""


import json, os
import pandas as pd
import numpy as np

# read the mapping info file
map_list_file = os.path.join(os.path.dirname(__file__), 'map_info.json')
map_list = json.load(open(map_list_file))

base_path = os.path.dirname(__file__)
map_dir = os.path.join(base_path, "map_files")


def get_list_of_mapping_ids():

	return list(map_list.keys())



def get_mapping_df(mapping_id):
	mapping = map_list[mapping_id]
	mapping_file = os.path.join(map_dir, mapping['file'])
	map_df = pd.read_csv(filepath_or_buffer=mapping_file,
						 sep=mapping['delim'],
						 skiprows=mapping['lines_skip'],
						 header=0,
						 dtype = str)
	# make sure to keep everything as strings, so we aren't rounding anything
	# pandas seems to do this as dtype = obj, but just in case

	map_df = map_df[mapping['col_names_orig']]
	map_df.columns = mapping['col_names']
	# print(map_df.iloc[0:25,].to_string())

	blanks = ["", "NA", "NaN", "NULL"] + [mapping['blank']]
	map_df.replace(to_replace=blanks, value=np.nan, inplace=True)
	# print(map_df.iloc[0:25,].to_string())

	return map_df



def get_mapping_file(mapping_id):
	return os.path.join(map_dir, map_list[mapping_id]['file'])


def get_map_lists_details():
	map_string = []
	for k,v in map_list.iteritems():
		map_string.append(k)
		map_string.append("\tfile: " + v["file"])
		map_string.append("\tcol_names_orig: " + ', '.join(v["col_names_orig"]))
		map_string.append("\tcol_names: " + ', '.join(v["col_names"]))
		map_string.append("\tlines_skip: " + str(v["lines_skip"]))
		map_string.append("\tdelim: " + v["delim"])
		map_string.append("\tblank: " + v["blank"])

	return map_string


if __name__ == "__main__":
	print('\n'.join(get_map_lists_details()))




