# Annotate

attach gene names, symbols, species database (e.g. SGD, MGI, etc) ids. Currently included are affymetrix yeast s98 and 2.0 probe sets. Also included is the SGD data for use to convert between systematic name, common name, and SGD ID, which can be used on RNA-seq data sets.

## Running

```python attach_gene_info.py <data_path> <data_col_id> <map_id> <map_col_id>```

* data_path: path to the data file to add info to
* data_col_id: data file column with probe id
* map_id: which mapping map_info.json, e.g. affy_yeast_2_35
* map_col_id: which col_names in map_info.json to map to data_col_id, e.g. probe

the data_col_id in your data should point to a column with gene ids, e.g. probe set ids, SGD IDs, systematic names, or gene symbols. You must select a map_col_id that matches that type.

example:                          
python attach_gene_info.py ../path/my_gene_data.tsv probe_sets affy_yeast_2_35 probe

currently available map ids are: 
* affy_yeast_2_35: affymetrix yeast 2.0, build 35
* affy_yeast_s98_35: affymetrix yeast 2.0, build 35
* sgd_yeast_2018: SGD database, for adding annotations without microarray probe ids

we acknowledge the use of the Affymetrix Analysis Center to obtain the map id files: https://www.affymetrix.com/analysis/netaffx_analysis_center_retired.html

currently available map col ids include:
"probe","sgd_id","sys_name","symbol"

to get help:  
`python attach_gene_info.py -h`

## Input 
`<data set name>.tsv`
* a tab delimited file
* comments rows start with a "#"
* a header row with column names
* one column with a gene id column (either species database id, symbol, systematic name (for yeast) microarray probe)

## Output
`<data set name>_annot.tsv`
* original tsv data with columns added for gene names, symbols, ids.
* saved to same directory as input data, with suffix "_annot" added to file name