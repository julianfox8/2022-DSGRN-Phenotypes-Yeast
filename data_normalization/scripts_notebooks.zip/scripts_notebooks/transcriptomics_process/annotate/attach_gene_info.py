"""
attach gene information to files.

uses map_info py and json to make consistent formats.
uses map files from platform (affy), species naming orgs (sgd, mgi, tair, etc.),
or from group for custom or older arrays (whitfield, spellman).
Our preference is to use probe <-> id maps from species naming orgs
when available.
Also handles replacing all the different types of blanks and nulls with np.nan
The new file will be written back into the data file directory,
with the suffix "annot" on the file name.

tested for: py 3.5

:author: Anastasia Deckard
:email: anastasia<dot>deckard<at>duke<dot>edu
:created: 2015 10 12
:copyright: (c) 2015, Anastasia Deckard
:license: New BSD License, see LICENSE for more details
"""

import os, sys, argparse
import pandas as pd
import data_rw as data_rw
import map_info as map_in

print("\n************************************************* \n" + \
          "    NOW RUNNING attach_gene_info.py \n" + \
          "************************************************* \n")

parser = argparse.ArgumentParser()
parser.add_argument("-data_path", help="path to the data file to add info to")
parser.add_argument("-data_col_id", help="data file column with probe id")
parser.add_argument("-map_id", help="which mapping map_info.json, e.g. affy_yeast_2")
parser.add_argument("-map_col_id", help="which col_names in map_info.json to map to data_col_id, e.g. probe")
parser.add_argument('-f','--fill_blank', nargs='+', help='if field is blank, fill from second field. e.g. symbol sys_name', required=False)
# in yeast it is common to not have a symbol, but have a sys_name; so if the symbol name is blank fill it with sys_name:
# --fill_blank symbol sys_name
parser.add_argument('-c','--compound_key', nargs='+', help='make a new key from two fields x_y, e.g. symbol probe', required=False)
# in certain microarrays, gene names are not unique, but we need unique ids. So we can make a compound key like symbol_probe:
# --compound_key symbol probe
args = parser.parse_args()

data_path = args.data_path
data_col_id = args.data_col_id
map_id = args.map_id
map_col_id = args.map_col_id
fill_blank = args.fill_blank
compound_key = args.compound_key

# store information on the processing
doc_for_file = data_rw.get_doc_info_string(__file__, __doc__, sys.argv, vars(parser.parse_args()))
print(doc_for_file)

if fill_blank is not None and len(fill_blank) == 2:
	fill_blank_cols = {fill_blank[0] : fill_blank[1]} #{"symbol":"sys_name"} for yeast is common
else:
	fill_blank_cols = {}

if compound_key is not None and len(compound_key) == 2:
	compound_key_cols = compound_key
else:
	compound_key = []


input_file_name, input_file_ext = os.path.splitext(os.path.basename(data_path))
out_path = data_path.replace(input_file_ext, "_annot" + input_file_ext)

data_df, data_comments = data_rw.read_tsv_to_df_w_comments(data_path)
map_df = map_in.get_mapping_df(map_id)

if fill_blank_cols:
	for key, value in fill_blank_cols.items():
		map_df[key].fillna(value=map_df[value], inplace=True)

print(len(data_df))
print(data_df.dtypes)
print(data_df.iloc[0:5,0:5].to_string())
print(len(map_df))
print(map_df.dtypes)
print(map_df.iloc[0:25,0:5].to_string())

combo_df = pd.merge(map_df, data_df, how='right', left_on=map_col_id, right_on=data_col_id)

if len(compound_key) > 0:
	compound_key_name = '_'.join(compound_key)
	compound_key_values = combo_df[compound_key].apply(lambda x: '_'.join([str(y) for y in x]), axis=1)
	combo_df.insert(0,compound_key_name, compound_key_values)

print("len combo: ", len(data_df))
print(combo_df.iloc[0:5,0:5].to_string())

# keep_data_cols = [item for item in list(combo_df.columns.values) if item not in remove_cols]
# combo_df = combo_df[keep_data_cols]

#combo_df.sort(columns=[list(combo_df.columns.values)[0]], ascending=True, inplace=True)

#print(combo_df.iloc[0:5,0:5].to_string())


print("saving to: " + out_path)
with open(out_path, 'w') as out_file:
	out_file.write("\n".join(data_comments) + "\n")
	out_file.write(doc_for_file)
	out_file.write("# data: %s\n" % data_path)
	out_file.write("# map: %s\n" % map_in.get_mapping_file(map_id))
	out_file.write("# \n")
	combo_df.to_csv(out_file, sep='\t', header=True, index=False)
