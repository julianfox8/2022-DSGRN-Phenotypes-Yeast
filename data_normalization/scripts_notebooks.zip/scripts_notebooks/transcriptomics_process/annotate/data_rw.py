"""
reading and writing of time series data files.

tested for: py 3.5

:author: Anastasia Deckard
:email: anastasia<dot>deckard<at>duke<dot>edu
:created: 2014 07 28
:copyright: (c) 2015, Anastasia Deckard
:license: New BSD License, see LICENSE for more details
"""

import os, sys, re
from datetime import datetime
import tarfile, zipfile
import pandas


def get_doc_info_string(file, doc, cmd, args):
	"""
	:param file:
	:param doc:
	:param cmd:
	:param args:
	:return:
	"""
	# doc_for_file = data_rw.get_doc_info_string(__file__, __doc__, sys.argv, vars(parser.parse_args()))
	# ''.join([x for x in doc.split('\n') if x.startswith(":version:")]),
	script_version = datetime.fromtimestamp(os.path.getmtime(file)).strftime("%Y %m %d %H:%M:%S")
	script_executed = datetime.today().strftime("%Y %m %d %H:%M:%S")

	doc_for_file = '\n'.join([
		"### script: " + os.path.basename(file) + " version: " + script_version,
		"# desc:     " + [x.strip() for x in doc.split('\n') if not x.startswith((":", " ", "\n"))][1],
# 		"# run by:   " + os.getlogin() + " " + script_executed,
		"# cmd:      " + ' '.join(cmd),
		"# params:   " + '\n#           '.join([str(x) + ": " + str(y) for x, y in args.items()]),
		"#\n"])

	return doc_for_file


def read_tsv_to_df_w_comments(filename, comment='#', sep='\t'):
	"""
	read a tsv file with commented lines to a pandas duke_data_ops frame

	:param filename: path to file
	:param comment: default is "#", symbol for comments
	:param sep: default is "\t", symbol for delimiter
	:returns: pandas Dataframe and list containing all comment lines.
	"""
	with open(filename, 'r') as file_handle:
		file_tmp = file_handle.read()
		file_tmp = file_tmp.splitlines()
		file_data = [line for line in file_tmp if not line.startswith(comment)]
		file_comments = [line for line in file_tmp if line.startswith(comment)]
		cols_names = file_data[0].split(sep)
		cols_data = [i.split(sep) for i in file_data[1:]]
		file_df = pandas.DataFrame(cols_data, columns=cols_names)

	return [file_df, file_comments]


def read_tsv_to_df(filename, comment='#', sep='\t'):
	"""read a tsv file with commented lines to a pandas duke_data_ops frame"""
	with open(filename, 'r') as file_handle:
		file_tmp = file_handle.read()
		file_tmp = file_tmp.splitlines()
		file_data = [line for line in file_tmp if not line.startswith(comment)]
		file_comments = [line for line in file_tmp if line.startswith(comment)]
		cols_names = file_data[0].split(sep)
		cols_data = [i.split(sep) for i in file_data[1:]]
		file_df = pandas.DataFrame(cols_data, columns=cols_names)

	return file_df


def read_tsv_zip_to_df_w_comments(zipname, filename, comment='#', sep='\t'):
	"""read a tsv file with commented lines to a pandas data frame"""
	with zipfile.ZipFile(zipname) as zip_handle:
		file_tmp = zip_handle.read(filename)
		file_tmp = file_tmp.splitlines()
		file_data = [line for line in file_tmp if not line.startswith(comment)]
		file_comments = [line for line in file_tmp if line.startswith(comment)]
		# if the files data is quoted csv, then strip the beginning and end quotes
		if sep == "\",\"":
			file_data = [re.sub(r'^"|"$', '', line) for line in file_data]
		cols_names = file_data[0].split(sep)
		cols_data = [i.split(sep) for i in file_data[1:]]
		file_df = pandas.DataFrame(cols_data, columns=cols_names)

	return [file_df, file_comments]


def read_tsv_tar_to_df_w_comments(tarname, filename, comment='#', sep='\t'):
	"""read a tsv file with commented lines to a pandas data frame"""
	with tarfile.open(tarname) as tar_handle:
		file_handle = tar_handle.extractfile(filename)
		file_tmp = file_handle.read()
		file_tmp = file_tmp.splitlines()
		file_data = [line for line in file_tmp if not line.startswith(comment)]
		file_comments = [line for line in file_tmp if line.startswith(comment)]
		# if the files data is quoted csv, then strip the beginning and end quotes
		if sep == "\",\"":
			file_data = [re.sub(r'^"|"$', '', line) for line in file_data]
		cols_names = [x.strip() for x in file_data[0].split(sep)]
		cols_data = [i.split(sep) for i in file_data[1:]]
		file_df = pandas.DataFrame(cols_data, columns=cols_names)

	return [file_df, file_comments]


def find_files_ends_with(dir, str_ends_with):
	file_paths = []
	for root, dirs, files in os.walk(dir):
		for file in files:
			if file.endswith(str_ends_with):
				# add the file paths to process
				file_paths.append(os.path.join(root, file))

	return file_paths
