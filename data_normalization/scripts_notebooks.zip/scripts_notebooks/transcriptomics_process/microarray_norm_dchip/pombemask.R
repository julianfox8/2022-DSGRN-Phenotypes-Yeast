library(yeast2probe)
library(yeast2cdf)
library(yeast2.db)

# load("SoybeanCutObjects.RData")
# s_cerev <- scan("s_cerevisiae.msk",skip=2,list("",""))
# pombe_filter_out <- s_cerev[[1]]
# 
# cleancdf <- cleancdfname("yeast2")
# RemoveProbes(listOutProbes=NULL,pombe_filter_out,"yeast2cdf","yeast2probe")

