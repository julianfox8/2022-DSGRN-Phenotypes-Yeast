# Gary Koplik (gary.koplik@geomdata.com)
# normalize_microarray_dchip.R

"
A NOTE FOR HOW TO USE THIS CODE
the code should be called on the command line the following way
  from the root directory `<path/to>/gda_transcriptomics_process/`

```
Rscript ./microarray_norm_dchip/normalize_microarray_dchip.R <path_dirs_to_normalize> <output_directory> <subdirectory_to_normalize_1> <subdirectory_to_normalize_2> <etc>
```

<path_dirs_to_normalize>: is the file_path that leads to all subdirectories of files to normalize

<output_directory> : path where output will be saved (with a timestamp in the folder name)

each <subdirectory_to_normalize> is a directory name inside <path_dirs_to_normalize> that contains EXACTLY THE FOLLOWING:
 1) the necessary metadata file which has the name identical to the subdirectory plus '_metadata.tsv'
      e.g. the `bristow2014_GSE49650` folder contains the file `bristow2014_GSE49650_metadata.tsv`
 2) a CEL file subdirectory that ends in '_RAW' that contains (at least all of) the CEL files specified in the related metadata file
"

# clear all output for replicability
rm(list = ls())

# installing necessary packages
#source("https://bioconductor.org/biocLite.R")
#biocLite("affy")
#biocLite("ArrayExpress")
#biocLite(c('yeast2.db', 'yeast2probe', 'yeast2cdf'))
#biocLite("limma")

library(affy)
library(lubridate)
library(tidyr)
library(yeast2probe)
library(ggplot2)
library(dplyr)
library(stringr)

source("./microarray_norm_dchip/pombemask.R")
source('./microarray_norm_dchip/ExtractIDs.R')
source('./microarray_norm_dchip/RemoveProbes.R')

mask_file = "./microarray_norm_dchip/s_cerevisiae.msk"

#### accumulate argv's into necessary data structures ####

# get a vector of all input strings
cmd <- commandArgs(trailingOnly = T)

# empty list of metadata directories to fill
sub_dirs <- c()

# these need to become argv's
for(i in 1:length(cmd)){
  # make sure directories end in "/"
  #  but not the subdirs
  if(str_sub(cmd[i], -1) != "/" & i < 3){
    cmd[i] <- paste0(cmd[i], "/")
  }
  # first input is root directory
  if(i == 1){
    root_dir <- cmd[i]
  }
  # second input is output directory
  else if(i == 2){
    output_dir <- cmd[i]
  }
  # all remaining directories are subdirectories contained in the root directory
  #  without any ending /
  else{
    # take off extra / at end of subdirectories if necessary
    #   (helps create metadata file paths later)
    if(str_sub(cmd[i], -1) == '/'){
      cmd[i] <- str_sub(cmd[i], 1, -2)
    }
    sub_dirs <- c(sub_dirs, cmd[i])
  }
}

metadata_files <- c() # one in each subdir
for(i in sub_dirs){
  # take off ending backslash for creating name of metadata file
  metadata_files <- c(metadata_files, paste0(root_dir, i, '/', i, '_metadata.tsv'))
}

# collect basenames into string to title files / folders accordingly
basenames_vec <- c()
for(i in metadata_files){
  basename_temp <- strsplit(basename(i), '_')[[1]][1]
  basenames_vec <- c(basenames_vec, basename_temp)
}
basenames <- paste(basenames_vec, collapse = '_')

# find raw folder in each subdirectory
cel_dirs <- c()

# find cel file directory from each specified subdirectory
for(j in sub_dirs){
  print(c('j: ', j))
  for(i in list.dirs(paste0(root_dir, j))){
    # directory with 'RAW' in name contains cel files
    if(grepl('RAW', i, fixed = T)){
      cel_dirs <- c(cel_dirs, paste0(i, '/'))
    }
  }
}


print(c("Path Dirs to Normalize: ", root_dir))
print(c("Output Dir: ", output_dir))
print(c("Sub Dirs: ", sub_dirs))
print(c("Metadata files: ", metadata_files))
print(c('basenames: ', basenames))
print(c('cel dirs: ', cel_dirs))

#### loop over metadata files to get needed cel files ####

# will need to loop over all argv input files and append values into one list
cel_files <- c()
types <- c()
fls <- c()
times <- c()

# for arg in sys.argv:
for(i in 1:length(metadata_files)){
  metadata_temp <- read.delim(metadata_files[i], comment.char = "#")
  cel_files_temp <- as.character(metadata_temp$file)
  
  
  # keep track of unique identifiers of experiment_condition_replicate for file naming later
  #   assumes metadata filename is like `nametokeep_otherinformation.tsv`
  types_temp <- paste(strsplit(basename(metadata_files[i]), '_')[[1]][1],
                      metadata_temp$condition,
                      paste0('r', metadata_temp$replicate), sep = "_")
  types <- c(types,  types_temp)
  
  times_temp <- paste(types_temp, metadata_temp$time, sep = '__')
  times <- c(times, times_temp)
  
  fls <- c(fls, paste0(cel_dirs[i], cel_files_temp))
}

#### read and normalize cel files to create yeast.matrix ####

dat <- ReadAffy(filenames = fls)

#Read in the mask file
s_cer = read.table(mask_file, skip=2, 
                   stringsAsFactors=FALSE)

c_df = ExtractIDs(s_cer[ ,1])

#Get the raw dataset for S. cerevisiae only

cleancdf = cleancdfname(dat@cdfName)
RemoveProbes(s_cer[, 1], cleancdf, 'yeast2probe') 

eset <- expresso(dat, normalize.method = "invariantset",
                 bgcorrect.method = "none",pmcorrect.method = "pmonly",
                 summary.method = "liwong")

yeast.matrix <- eset@assayData$exprs
orig_names <- colnames(yeast.matrix)
colnames(yeast.matrix) <- times

# save yeast.matrix

timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
# save within user-specified output directory
output_dir <- paste0(output_dir, basenames, "_dchip_", timestamp, "/")
dir.create(output_dir, recursive = T)

out_file_all <- paste0(output_dir, basenames, '_dchip_', timestamp, "_all", ".tsv")
cat(file = out_file_all, paste0("# normalized time series: ", paste(basenames_vec, collapse = ", "), "\n",
                                "# normalized with: ", paste(unique(types), collapse = ", "), "\n",
                                "# algorithm: dChip \n",
                                "# by: Gary Koplik (gary.koplik@geomdata.com) \n",
                                "# executed by: Robert C. Moseley (robert.moseley@duke.edu)",
                                "# on: ", today(), "\n",
                                "# \n",
                                "probe\t")
)
write.table(yeast.matrix, file = out_file_all,
            row.names = T, sep = "\t", append = T, quote = F)


#### save yeast.matrix parts by type ####

for(i in 1:length(unique(types))){
  temp <- as.data.frame(yeast.matrix)[ , types == unique(types)[i]]
  colnames(temp) <- gsub('.*__', '', colnames(temp))
  out_file <- paste0(output_dir, unique(types)[i], "_dchip_", timestamp, "_ts", ".tsv")
  cat(file = out_file, paste0("# normalized time series: ", unique(types)[i], "\n",
                              "# normalized with: ", paste(unique(types), collapse = ", "), "\n",
                              "# algorithm: dChip \n",
                              "# by: Gary Koplik (gary.koplik@geomdata.com) \n",
                              "# executed by: Robert C. Moseley (robert.moseley@duke.edu)",
                              "# on: ", today(), "\n",
                              "# \n",
                              "probe\t")
  )
  write.table(temp, file = out_file,
              row.names = T, sep = "\t", append = T, quote = F)
}

# save all CEL files used in normalization into a readme
read_me_out_file <- paste0(output_dir, basenames,  "_dchip_", timestamp, "_readme.tsv")
cat(file = read_me_out_file,
    paste0("filename: ", paste0("dchip_", timestamp, "_readme.tsv"), "\n",
           "normalized with: ", paste(unique(types), collapse = ", "), "\n",
           "algorithm: dChip \n",
           "by: Gary Koplik (gary.koplik@geomdata.com) \n",
           "# executed by: Robert C. Moseley (robert.moseley@duke.edu)",
           "on: ", today(), "\n",
           "CEL files normalized with: \n",
           paste(orig_names, collapse = '\n'))
)

# to get write.table to cooperate
empty_df <- data.frame()

write.table(empty_df, file = read_me_out_file, sep = "\t", append = T, quote = F)



#### reshape yeast.matrix for violin plot below ####

yeast_dat <- tidyr::gather(as.data.frame(yeast.matrix),
                           key = "type", value = "expression") %>%
  mutate(cond = gsub("\\__.*", "", type)) %>%
  dplyr::select(-type)

#### violin plot ####

ggplot(yeast_dat) +
  geom_violin(aes(x = "", y = expression, group = cond, fill = cond)) +
  ylab("Density of Gene Expression") +
  xlab("Type") +
  ggtitle("Violin Plots of Gene Expressions by Type") +
  labs(subtitle = "Normalized with dChip") +
  guides(fill = guide_legend(title = "Type")) +
  theme_bw()

ggsave(filename = paste0(output_dir, "/norm_gene_exp_dist.png"),
       width = 15, height = 4.0, units = "in")




