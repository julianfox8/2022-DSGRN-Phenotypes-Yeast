norminvset2 <- function (abatch, prd.td = c(0.003, 0.007), verbose = FALSE, 
    baseline.type = c("mean", "median", "pseudo-mean", "pseudo-median"), 
    type = c("separate", "pmonly", "mmonly", "together")) 
{
    do.normalize.Affybatch.invariantset <- function(abatch, pms, 
        prd.td, baseline.type) {
        nc <- length(abatch)
        if (baseline.type == "mean") {
            m <- vector("numeric", length = nc)
            for (i in 1:nc) m[i] <- mean(intensity(abatch)[pms, 
                i])
            refindex <- match(trunc(median(rank(m))), rank(m))
            rm(m)
            baseline.chip <- c(intensity(abatch)[pms, refindex])
            if (verbose) 
                cat("Data from", sampleNames(abatch)[refindex], 
                  "used as baseline.\n")
        }
        else if (baseline.type == "median") {
            m <- vector("numeric", length = nc)
            for (i in 1:nc) m[i] <- median(intensity(abatch)[pms, 
                i])
            refindex <- match(trunc(median(rank(m))), rank(m))
            rm(m)
            baseline.chip <- c(intensity(abatch)[pms, refindex])
            if (verbose) 
                cat("Data from", sampleNames(abatch)[refindex], 
                  "used as baseline.\n")
        }
        else if (baseline.type == "pseudo-mean") {
            refindex <- 0
            baseline.chip <- rowMeans(intensity(abatch)[pms, 
                ])
        }
        else if (baseline.type == "pseudo-median") {
            refindex <- 0
            baseline.chip <- rowMedians(intensity(abatch)[pms, 
                ])
        }
        normhisto <- vector("list", length = nc)
        invsets <- vector("list",length = (nc-1))
        probe.ids <- unlist(pmindex(abatch))
        ctr <- 1
        for (i in (1:nc)) {
            if (i != refindex) {
                if (verbose) {
                  cat("normalizing array", sampleNames(abatch)[i], 
                    "...")
                }
                tmp <- normalize.invariantset(c(intensity(abatch)[pms, 
                  i]), c(baseline.chip), prd.td)
                invsets[[ctr]] <- probe.ids[tmp$i.set]
                tmp <- as.numeric(approx(tmp$n.curve$y, tmp$n.curve$x, 
                  xout = intensity(abatch)[pms, i], rule = 2)$y)
                #attr(tmp, "invariant.set") <- NULL
                intensity(abatch)[pms, i] <- tmp
                ctr <- ctr + 1
                if (verbose) {
                  cat("done.\n")
                }
            }
        }
        attr(abatch, "normalization") <- normhisto
        attr(abatch, "invariant.sets") <- invsets
        return(abatch)
    }
    type <- match.arg(type)
    baseline.type <- match.arg(baseline.type)
    if (type == "pmonly") {
        pms <- unlist(pmindex(abatch))
        do.normalize.Affybatch.invariantset(abatch, pms, prd.td, 
            baseline.type)
    }
    else if (type == "mmonly") {
        pms <- unlist(mmindex(abatch))
        do.normalize.Affybatch.invariantset(abatch, pms, prd.td, 
            baseline.type)
    }
    else if (type == "together") {
        pms <- unlist(indexProbes(abatch, "both"))
        do.normalize.Affybatch.invariantset(abatch, pms, prd.td, 
            baseline.type)
    }
    else if (type == "separate") {
        pms <- unlist(pmindex(abatch))
        abatch <- do.normalize.Affybatch.invariantset(abatch, 
            pms, prd.td, baseline.type)
        pms <- unlist(mmindex(abatch))
        do.normalize.Affybatch.invariantset(abatch, pms, prd.td, 
            baseline.type)
    }
}

expresso2 <- function (afbatch, bg.correct = TRUE, bgcorrect.method = NULL, 
    bgcorrect.param = list(), normalize = TRUE, normalize.method = NULL, 
    normalize.param = list(), pmcorrect.method = NULL, pmcorrect.param = list(), 
    summary.method = NULL, summary.param = list(), summary.subset = NULL, 
    verbose = FALSE, widget = FALSE, inv.sets=FALSE) 
{
    setCorrections <- function() {
        bioc.opt <- getOption("BioC")
        if (bg.correct) {
            if (is.null(bgcorrect.method)) {
                BGMethods <- bgcorrect.methods()
            }
            else {
                BGMethods <- bgcorrect.method
            }
        }
        else {
            BGMethods <- "None"
        }
        if (normalize) {
            if (is.null(normalize.method)) {
                normMethods <- normalize.methods(afbatch)
            }
            else {
                normMethods <- normalize.method
            }
        }
        else {
            normMethods <- "None"
        }
        if (is.null(pmcorrect.method)) {
            PMMethods <- pmcorrect.methods()
        }
        else {
            PMMethods <- pmcorrect.method
        }
        if (is.null(summary.method)) {
            expMethods <- generateExprSet.methods()
        }
        else {
            expMethods <- summary.method
        }
        corrections <- expressoWidget(BGMethods, normMethods, 
            PMMethods, expMethods, bioc.opt$affy$bgcorrect.method, 
            bioc.opt$affy$normalize.method, bioc.opt$affy$pmcorrect.method, 
            bioc.opt$affy$summary.method)
        if (!is.null(corrections)) {
            if (corrections[["BG"]] != "None") {
                bgcorrect.method <<- corrections[["BG"]]
            }
            if (corrections[["NORM"]] != "None") {
                normalize.method <<- corrections[["NORM"]]
            }
            if (corrections[["PM"]] != "None") {
                pmcorrect.method <<- corrections[["PM"]]
            }
            if (corrections[["EXP"]] != "None") {
                summary.method <<- corrections[["EXP"]]
            }
        }
        else {
            stop("Aborted by user")
        }
    }
    if (widget) {
        require(tkWidgets) || stop("library tkWidgets could not be found !")
    }
    nchips <- length(afbatch)
    if (widget) {
        setCorrections()
    }
    if (verbose) {
        if (bg.correct) {
            cat("background correction:", bgcorrect.method, "\n")
        }
        if (normalize) {
            cat("normalization:", normalize.method, "\n")
        }
        cat("PM/MM correction :", pmcorrect.method, "\n")
        cat("expression values:", summary.method, "\n")
    }
    if (bg.correct) {
        if (verbose) 
            cat("background correcting...")
        afbatch <- do.call(affy:::bg.correct, c(alist(afbatch, 
            method = bgcorrect.method), bgcorrect.param))
        if (verbose) 
            cat("done.\n")
    }
    if (normalize) {
        if (verbose) 
            cat("normalizing...")
        print("normalize.method=")
        print(normalize.method)
        if (normalize.method == "invariantset") {
            print("Calling norminvset2")
            afbatch <- norminvset2(afbatch,verbose=verbose)
        }
        else {
			afbatch <- do.call(affy:::normalize, c(alist(afbatch, 
	        normalize.method), normalize.param))
	    }
        if (verbose) 
            cat("done.\n")
    }
    eset <- computeExprSet(afbatch, summary.method = summary.method, 
        pmcorrect.method = pmcorrect.method, ids = summary.subset, 
        summary.param = summary.param, pmcorrect.param = pmcorrect.param)
    if (inv.sets) {    
    	return(list(eset=eset,invsets=attr(afbatch,"invariant.sets")))
    }
    else {
    	return(eset)
    }
}