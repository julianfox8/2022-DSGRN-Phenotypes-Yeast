#!/bin/sh

cd transcriptomics_process/get_metadata_from_geo

python extract_geo_metadata.py -data_path ../../../data/GSE75694/GSE75694_series_matrix.txt -dataset_name cho2019 -skiprows 25

python extract_geo_metadata.py -data_path ../../../data/GSE8799/GSE8799_series_matrix.txt -dataset_name orlando2008 -skiprows 26

python extract_geo_metadata.py -data_path ../../../data/GSE32974/GSE32974_series_matrix.txt -dataset_name simmonskovacs2012 -skiprows 25

python extract_geo_metadata.py -data_path ../../../data/GSE96997/GSE96997_series_matrix.txt -dataset_name cho2017 -skiprows 25

python extract_geo_metadata.py -data_path ../../../data/GSE49650/GSE49650_series_matrix.txt -dataset_name bristow2014 -skiprows 25

cd -
