#!/bin/sh

cd transcriptomics_process/annotate

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE32974_cdc28-4_37C_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE49650_cdc20_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/cdc20_cdc20;nrm1_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE49650_cse4_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537_all.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE49650_cse4_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE49650_cdc20_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE32974_cdc28-4_37C_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE49650_rad53_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/alphafactor_alphafactor_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE75694_cdc28whi5stb1_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE75694_cdc16cdc28whi5stb1_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE32974_wild-type_37C_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE75694_cdc16cdc28whi5stb1_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/alphafactor_alphafactor_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE49650_rad53_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE75694_cdc28whi5stb1_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE96997_cdc15-2_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE49650_cdc8cdc20_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/clb1-6_CHX_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/dun1_dun1;cdc8;cdc20_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE49650_cdc8_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE49650_cdc8_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/dun1_dun1;cdc8;cdc20_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/15D_rho0;clb1-6_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE8799_CyclinMutant_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/15D_rho0_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE8799_WildType_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE75694_GAL-SIC1Δ3P_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE75694_cdc28whi5stb1_elutr_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE96997_cdc14-3_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE75694_cdc28whi5stb1_elutr_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE75694_GAL-SIC1Δ3P_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE75694_GAL-SIC1Δ3P_nrm1Δyhp1Δyox1Δ_r1_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/15D_rho0_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE8799_WildType_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

python attach_gene_info.py -data_path "../../../normalizations/dchip_mass_norm/15D_alphafactor_dun1_GSE49650_15D_clb1-6_GSE96997_alphafactor_dun1_GSE32974_GSE8799_cdc20_15D_GSE75694_dchip_20201123_133537/GSE8799_CyclinMutant_r2_dchip_20201123_133537_ts.tsv" -data_col_id "probe" -map_id "affy_yeast_2_35" -map_col_id "probe"

cd -
